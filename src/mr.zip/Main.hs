module Main where

import MapReduce
import IO
import System.Environment (getArgs)
import Control.Monad (liftM)
import Prelude hiding (return,(>>=))
import qualified Prelude as P



main::IO()
main = do
        args <- getArgs
        state <- getLines (head args)
        let res = mapReduce state
        putStrLn $ show res

-- perform MapReduce

mapReduce :: [String] -> [(String,Int)]
mapReduce state = runMapReduce mr state
        where
        mr = distributeMR >>= wrapMR mapper >>= wrapMR reducer 

-- transformers

mapper :: [String] -> [(String,String)]
mapper [] = []
mapper (x:xs) = parse x ++ mapper xs
        where
        parse x = map (\w -> (w,w)) $ words x

reducer :: [String] -> [(String,Int)]
reducer [] = []
reducer xs = [(head xs,length xs)]

-- get input

getLines :: FilePath -> IO [String]
getLines file = do
        h <- openFile file ReadMode
        text <- hGetContents h
        P.return (lines text) 

 
                      