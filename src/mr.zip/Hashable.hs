{-# LANGUAGE TypeSynonymInstances #-}

module Hashable (Hashable, hash) where

import qualified Crypto.Hash.MD5 as H
import Data.Char (ord)
import Data.ByteString (ByteString,pack,unpack,singleton)
import Data.Bits (xor,(.&.))

{- THE HASHABLE CLASS -}

-- class definition; any type that can be converted to ByteString is hashable

class Hashable s where
        conv :: s -> ByteString
        
-- the hash function

hash :: (Hashable s) => s -> Int
hash s = sum $ map fromIntegral (unpack h)
        where
        h = H.hash $ conv s        

{- INSTANCES OF THE CLASS -}
        
-- make String Hashable

instance Hashable String where
        conv s = pack $ map (fromIntegral . ord) s
        
instance Hashable Integer where
        conv 0 = singleton 0
        conv x = pack . map fromIntegral $ conv' x
                where
                conv' 0 = []
                conv' y = (y .&. 255):conv' (y `div` 256)

instance Hashable ByteString where
        conv = id         
        
               