module MapReduce (MapReduce, Hashable, return, (>>=), runMapReduce, 
        distributeMR, wrapMR) where

import Data.List (nub)
import Control.Applicative ((<$>))
import Control.Monad (liftM)
import Control.DeepSeq (NFData)
import IO
import Prelude hiding (return,(>>=))
import Hashable (Hashable,hash)
import qualified ParallelMap as P

{-- TYPE DEFINITIONS --}

-- the generalised Monad

class Monad' m where
        return :: a -> m s x s a
        (>>=)  :: (Eq b,NFData s'',NFData c) => m s a s' b 
                -> ( b -> m s' b s'' c ) -> m s a s'' c

-- the generalised MapReduce data type

newtype MapReduce s a s' b = MR { runMR :: ([(s,a)] -> [(s',b)]) }

-- the generalised MapReduce type as an instance of Monad'

instance Monad' MapReduce where
        return = retMR
        (>>=)  = bindMR
        
{-- definition of the Monad' operations for MapReduce --}

-- the return function

retMR :: a -> MapReduce s x s a
retMR k = MR (\ss -> [(s,k) | s <- fst <$> ss])

-- the monadic composition function
       
bindMR :: (Eq b,NFData s'',NFData c) => MapReduce s a s' b 
        -> (b -> MapReduce s' b s'' c) -> MapReduce s a s'' c
bindMR f g = MR (\s ->
        let
                fs = runMR f s
                gs = map g $ nub $ snd <$> fs
        in
        concat $ P.map (\g' -> runMR g' fs) gs)         

{-- utility functions --}

-- execute a MapReduce Monad' given specified initial state

runMapReduce :: MapReduce s () s' b -> [s] -> [(s',b)]
runMapReduce m ss = (runMR m) [(s,()) | s <- ss]

-- distribute key values of a data set using a hash
       
distributeMR :: (Hashable s) => MapReduce s () s Int
distributeMR = MR (\ss -> [(s,hash s) | s <- fst <$> ss])

                

-- wrap a traditional mapper / reducer in a monadic function

wrapMR :: (Eq a) => ([s] -> [(s',b)]) -> (a -> MapReduce s a s' b)
wrapMR f = (\k -> MR (g k))
        where
        g k ss = f $ fst <$> filter (\s -> k == snd s) ss

       
        

 
              